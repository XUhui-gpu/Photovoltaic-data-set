clear
close all
clc
format short 
setdemorandstream(1);
%% 数据导入
load("pv_out_24mean.mat")
load("weather.mat")
load("PV_out_all.mat")
load("date.mat")

PV_out_all_flatten_t = reshape(PV_out_all,21696,1);
PV_out_24 = [];
for i = 1:5424
    PV_out_24 = [PV_out_24;mean(PV_out_all_flatten_t(4*i-3:4*i,:))];
end


%% 数据集划分
RMSE = [];
R2 = [];
PREDICT_our = [];
PREDICT_our_ETTAO = [];
PV_validout_N = [];
CApEnN = [];
INDEXN = [];
PV_validout_near_N = [];
tic
for mm = 1:42

weather_test_t = [];
INDEXX1 = [];
INDEXX2 = [];
index = [];
weather_store = [];
PVtrain = [];
PVtrain2 = [];
PVtest = [];
Ytrain = [];
weathertrain = [];
weather_storee = [];
weather_storeee = [];
weather_storeee_e = [];
weather_storee_e_y = [];
weather_storee_y = [];
weather_storee_yy = [];
weather_valid = [];
weather__valid_s_N = [];


nu = 293+mm;
rho1 = corr(weather((nu)*16+1:(296+mm)*16,1), PV_out_24((nu)*16+1:(296+mm)*16));
rho2 = corr(weather((nu)*16+1:(296+mm)*16,2), PV_out_24((nu)*16+1:(296+mm)*16));
rho9 = corr(weather((nu)*16+1:(296+mm)*16,9), PV_out_24((nu)*16+1:(296+mm)*16));
rho10 = corr(weather((nu)*16+1:(296+mm)*16,10), PV_out_24((nu)*16+1:(296+mm)*16));
rho11 = corr(weather((nu)*16+1:(296+mm)*16,11), PV_out_24((nu)*16+1:(296+mm)*16));




%% 时段相似匹配数据库建立
[weather_guiyi,weather_guiyips]=mapminmax(weather(1:(296+mm)*16,:)',0,1); 
weather_guiyi = weather_guiyi';
weather_testt = weather((296+mm)*16+1:(297+mm)*16,:);
weather_testt_guiyi = mapminmax('apply',weather_testt',weather_guiyips); 
weather_testt_guiyi = weather_testt_guiyi';
weather_testt_guiyi(:,[3,4,5,6,7,8]) = [];
weather_guiyi(:,[3,4,5,6,7,8]) = [];
weather_guiyi(:,1) = weather_guiyi(:,1)*abs(rho1);
weather_guiyi(:,2) = weather_guiyi(:,2)*abs(rho2);
weather_guiyi(:,3) = weather_guiyi(:,3)*abs(rho9);
weather_guiyi(:,4) = weather_guiyi(:,4)*abs(rho10);
weather_guiyi(:,5) = weather_guiyi(:,5)*abs(rho11);

weather_testt_guiyi(:,1) = weather_testt_guiyi(:,1)*abs(rho1);
weather_testt_guiyi(:,2) = weather_testt_guiyi(:,2)*abs(rho2);
weather_testt_guiyi(:,3) = weather_testt_guiyi(:,3)*abs(rho9);
weather_testt_guiyi(:,4) = weather_testt_guiyi(:,4)*abs(rho10);
weather_testt_guiyi(:,5) = weather_testt_guiyi(:,5)*abs(rho11);

weather_y = weather;
weather_y(:,[3,4,5,6,7,8]) = [];

for i = 1:296+mm
weather_storee = [weather_storee,weather_guiyi(i*16-15:i*16,:)];
weather_storee_y = [weather_storee_y,weather(i*16-15:i*16,:)];
weather_storee_yy = [weather_storee_yy,weather_y(i*16-15:i*16,:)];
end
weather_storee2 = flipud(weather_storee);
weather_storee2_y = flipud(weather_storee_y);
for ii = 1:8
    weather_test_t(ii,:) = reshape(weather_testt_guiyi(2*ii-1:2*ii,:),10,1);
end
for ii = 1:15  
    weather_storeee_e(:,:,ii) = reshape(weather_storee(ii:ii+1,:),10,296+mm);
    weather_storeee_e(:,:,ii+15) = reshape(weather_storee2(ii:ii+1,:),10,296+mm);
    weather_storee_e_y(:,:,ii) =  reshape(weather_storee_y(ii:ii+1,:),22,296+mm);
    weather_storee_e_y(:,:,ii+15) =  reshape(weather_storee2_y(ii:ii+1,:),22,296+mm);
end


distance1 = [];
distance2 = [];
index1 = [];
index2 = [];
n_num = 4;
for ii = 1:30
[D,I] = pdist2(weather_storeee_e(:,:,ii)',weather_test_t,'euclidean','Smallest',n_num);
for i = 1:n_num
distance(ii,:,i) = D(i,:);
index(ii,:,i) =I(i,:);
end
end
[~,I_1] = min(distance,[],1);
for ii = 1:8
for i = 1:n_num
I_2(i,ii) = index(I_1(1,ii,i),ii,i);
end
end

PV_out_all2 = flipud(PV_out_all);
for ii = 1:15
    PV_out_s(:,:,ii) = PV_out_all(4*ii-3:4*ii+4,:);
    PV_out_s(:,:,ii+15) = PV_out_all2(4*ii-3:4*ii+4,:);
end
for i = 1:n_num
for ii = 1:8  
    PV_sim(:,ii,i) = PV_out_s(:,I_2(i,ii),I_1(1,ii,i));    
end
end
for i = 1:n_num
PV_validout(:,i) = reshape(PV_sim(:,:,i),64,1);
end
PV_validout_N = [PV_validout_N;PV_validout];
PV_validout_near = PV_validout(:,1)*0.4+PV_validout(:,2)*0.3+PV_validout(:,3)*0.2+PV_validout(:,4)*0.1;
PV_validout_near_N = [PV_validout_near_N;PV_validout_near];



PV_testout = PV_out_all(:,298:339);
PV_testout = reshape(PV_testout,42*64,1);


% %% 相似日数据集构建
% 
% for ii = 1:296+mm
%     AE = abs(PV_validout_near - PV_out_all(:,ii));
%     AUC_1 = trapz(AE);
%     AUC_2 = trapz(PV_validout_near);
%     res_qian = AUC_1/AUC_2;
%     CApEn(ii) = res_qian;
% end
% 
% [CApEn,index] = sort(CApEn,"descend");
% INDEX = find(CApEn<=0.6);
% nn = length(INDEX);
% 
% if nn <= floor((296+mm)*0.5)
%     nn = floor((296+mm)*0.5);
% end
% 
% INDEXN = [INDEXN;nn];
% 
% 
% PV_test = PV_out_all(:,index(294+mm-nn:296+mm));
% PV_t = reshape(PV_test,(nn+3)*64,1);
% PV_testin = PV_test(nn*64+1:(nn+3)*64);
% 
% tem_stt = reshape(weather(:,1),16,339);
% tem_st = tem_stt(:,index);
% hum_stt = reshape(weather(:,2),16,339);
% hum_st = hum_stt(:,index);
% Shr_stt = reshape(weather(:,9),16,339);
% Shr_st = Shr_stt(:,index);
% Dnr_stt = reshape(weather(:,10),16,339);
% Dnr_st = Dnr_stt(:,index);
% Sr_stt = reshape(weather(:,11),16,339);
% Sr_st = Sr_stt(:,index);
% 
% for ii = 1:nn
%     PVtrain(:,ii) = PV_t((ii-1)*64+1:(ii-1)*64+192,1); 
%     Ytrain(:,ii) = PV_t((ii-1)*64+193:ii*64+192,1);
% end
% 
% for ii = 1:1
%     PVtest(:,ii) = PV_testin((ii-1)*64+1:(ii-1)*64+192);
% end
% 
% 
% 
% [inputn1,inputps1]=mapminmax(PVtrain,0,1);         % 训练集输入归一化到[0,1]之间
% 
% 
% [temn,temps]=mapminmax(tem_st(:,end-nn+1:end),0,1); 
% [humn,humps]=mapminmax(hum_st(:,end-nn+1:end),0,1); 
% [Shrn,Shrps]=mapminmax(Shr_st(:,end-nn+1:end),0,1); 
% [Dnrn,Dnrps]=mapminmax(Dnr_st(:,end-nn+1:end),0,1); 
% [Srn,Srps]=mapminmax(Sr_st(:,end-nn+1:end),0,1); 
% 
% [outputn,outputps]=mapminmax(Ytrain,0,1);  
% 
% 
% inputn_test1=mapminmax('apply',PVtest(1:192,:),inputps1);   
% 
% 
% temn_test=mapminmax('apply',reshape(weather(4753+(mm-1)*16:4752+16*mm,1),16,1),temps);
% humn_test=mapminmax('apply',reshape(weather(4753+(mm-1)*16:4752+16*mm,2),16,1),humps);
% Shrn_test=mapminmax('apply',reshape(weather(4753+(mm-1)*16:4752+16*mm,9),16,1),Shrps);
% Dnrn_test=mapminmax('apply',reshape(weather(4753+(mm-1)*16:4752+16*mm,10),16,1),Dnrps);
% Srnn_test=mapminmax('apply',reshape(weather(4753+(mm-1)*16:4752+16*mm,11),16,1),Srps);
% 
% 
% inputn_in = [temn;humn;Shrn;Dnrn;Srn;inputn1];
% inputn_test_in =[temn_test;humn_test;Shrn_test;Dnrn_test;Srnn_test;inputn_test1];
% 
% 
% % XrTrain = cell(nn,1);
% % YrTrain = cell(nn,1);
% % 
% % for ii=1:nn
% %     XrTrain{ii,1} = inputn_in(:,ii);
% %     YrTrain{ii,1} = outputn(:,ii);
% % end
% % XrTest = cell(1,1);
% % for ii = 1:1
% % XrTest{ii,1} = inputn_test_in(:,ii);      
% % end
% 
% XrTrain = cell(nn,1);
% YrTrain = zeros(nn,64);
% for ii=1:nn
%     XrTrain{ii,1} = inputn_in(:,ii);
%     YrTrain(ii,:) = outputn(:,ii);
% end
% 
% 
% XrTest = cell(1,1);
% XrValid = cell(1,1);
% for ii = 1:1
% XrTest{ii,1} = inputn_test_in(:,ii);      
% 
% end
% 
% %% 模型构建
% %% LSTM/BILSTM/GRU
% layer = [
%         sequenceInputLayer(272,Normalization="rescale-symmetric",Name="input") ];
% lgraph = layerGraph(layer);
% outputName = layer.Name;
% 
% layers = [
% 
%           lstmLayer(256,'Name','layer1')            
%           lstmLayer(128,'OutputMode',"last",'Name','layer2')
% 
%           fullyConnectedLayer(64,'Name','fc')
%           regressionLayer('Name','output') ];
% 
% 
% lgraph = addLayers(lgraph,layers);
% lgraph = connectLayers(lgraph,outputName,'layer1');
% 
% %% MSLCnet
% 
% % num = 1;
% % layer = [
% %         sequenceInputLayer(272,Normalization="rescale-symmetric",Name="input") ];
% % lgraph = layerGraph(layer);
% % outputName = layer.Name;
% % layers = [        
% %         lstmLayer(256,"Name","l1")       
% %         lstmLayer(128,"Name","l2")
% %            ];
% % layers2 = [
% %             convolution1dLayer(3,num,'Padding','same','Name','conv1');
% %             reluLayer
% %             convolution1dLayer(2,num,'Padding','same','Name','conv2');
% %             reluLayer
% %             convolution1dLayer(6,num,'Padding','same','Name','conv3');
% %             reluLayer
% %             additionLayer(2,"Name","add1")
% %             concatenationLayer(1,2,Name="concat")
% %             selfAttentionLayer(1,12)
% %             fullyConnectedLayer(64,'Name','fc')
% %             regressionLayer('Name','output')];
% % lgraph = addLayers(lgraph,layers2);
% % lgraph = addLayers(lgraph,layers);
% % lgraph = connectLayers(lgraph,outputName,"l1");
% % lgraph = connectLayers(lgraph,outputName,'conv1');
% % layer = convolution1dLayer(1,num,Name="convSkip");
% % lgraph = addLayers(lgraph,layer);
% % lgraph = connectLayers(lgraph,outputName,"convSkip");
% % lgraph = connectLayers(lgraph,"convSkip",'add1/in2');
% % lgraph = connectLayers(lgraph,"l2","concat/in2");
% 
% 
% 
% options1 = trainingOptions( 'adam', ...
%     'MaxEpochs',100, ...
%     'MiniBatchSize',nn, ...
%     'GradientThreshold',1, ...
%     'InitialLearnRate',0.01, ...
%     'LearnRateSchedule','piecewise', ...
%     'LearnRateDropPeriod',floor(nn), ...
%     'LearnRateDropFactor',0.5, ...
%     'L2Regularization',0.005,...
%     'Verbose',false, ...
%     'Plots','none' );
% 
% %% 网络训练
% 
% net0 = trainNetwork(XrTrain,YrTrain,lgraph,options1);
% 
% % 预测结果
% 
% 
% YPred = predict(net0,XrTest);
% 
% YPred = double(YPred');
% 
% % YPred = cell2mat(YPred);
% 
% 
% % 反归一化
% test_fgy0=mapminmax('reverse',YPred,outputps); 
% 
% 
% for iii = 1:64
%     if test_fgy0(iii) <0
%         test_fgy0(iii) = 0;
%     end
% end
% 
% test_out_ = PV_testout(64*mm-63:64*mm);
% test_fgy0 = reshape(test_fgy0,64,1);
% error=abs(test_fgy0-test_out_);  
% rmse = sqrt(mean((test_fgy0-(test_out_)).^2,'ALL'));
% d_max = max(test_out_);
% d_min = min(test_out_);
% nrmse = rmse/(d_max-d_min);
% r2 = 1 - norm(test_out_ -  test_fgy0)^2 / norm(test_out_ -  mean(test_out_ ))^2;
% mae = mean(error);
% nmae = mae/(d_max-d_min);
% mape = mean(error./test_out_);
% res_hou = Area_deviation_rate_calculation(test_fgy0,test_out_);
% disp('****************************************')
% disp(['天数：',num2str(mm)])
% disp(['总体准确度：',num2str(mean(res_hou))])
% disp(['优化前的NRMSE：',num2str(mean(nrmse))])
% disp(['优化前的nmae：',num2str(mean(nmae))])
% disp(['优化前的R2：',num2str(mean(r2))])
% PREDICT_our = [PREDICT_our,test_fgy0];


end
toc
% PREDICT_our = reshape(PREDICT_our,2688,1);
PREDICT_our = reshape(PV_validout_near_N,2688,1);
PV_Testout = PV_testout(1:2688);
AE2= abs(PREDICT_our - PV_Testout);
RMSE2 = (mean(AE2.^2)).^0.5;
d_max = max(PV_Testout);
d_min = min(PV_Testout);
NRMSE1 = RMSE2/(d_max-d_min);
MSE2 = mean(AE2.^2);
MAE2 = mean(AE2);
NMAE1 = MAE2/(d_max-d_min);
MAPE2 = mean(AE2./PV_Testout);
R_2_2 = 1 - norm(PV_Testout -  PREDICT_our)^2 / norm(PV_Testout-mean(PV_Testout))^2;
disp('**********************************')
disp('优化前总体预测结果评价指标：')
res_hou = Area_deviation_rate_calculation(PREDICT_our,PV_Testout);
disp(['总体准确度：',num2str(mean(res_hou))])
disp(['总体NRMSE = ', num2str(NRMSE1)])
disp(['总体NMAE  = ', num2str(NMAE1)])                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
disp(['总体决定系数R^2为：  ',num2str(R_2_2)])
PREDICT_LSTM = PREDICT_our;
PREDICT_our2 = PREDICT_our;







