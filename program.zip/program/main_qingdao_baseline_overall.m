clear
close all
clc
format short 
setdemorandstream(1);
%% 数据导入
load("pv_out_24mean.mat")
load("weather.mat")
load("PV_out_all.mat")
load("date.mat")


PV_out_all_flatten_t = reshape(PV_out_all,21696,1);
PV_out_24 = [];
for i = 1:5424
    PV_out_24 = [PV_out_24;mean(PV_out_all_flatten_t(4*i-3:4*i,:))];
end


%% 数据集划分
RMSE = [];
R2 = [];
PREDICT_our = [];
PREDICT_LSTM = [];
PV_validout_N = [];
CApEnN = [];
INDEXN = [];
PV_validout_near_N = [];
PV_testout = PV_out_all(:,298:339);
PV_testout = reshape(PV_testout,42*64,1);

tic
PV_use = PV_out_all(:,1:339);
PV_t = reshape(PV_use,339*64,1);
PV_testin = PV_use(294*64+1:339*64);

for ii = 1:294
    PVtrain(:,ii) = PV_t((ii-1)*64+1:(ii-1)*64+192,1); 
    Ytrain(:,ii) = PV_t((ii-1)*64+193:ii*64+192,1);
end

for ii = 1:42
    PVtest(:,ii) = PV_testin((ii-1)*64+1:(ii-1)*64+192);
end



[inputn1,inputps1]=mapminmax(PVtrain,0,1);         % 训练集输入归一化到[0,1]之间

[temn,temps]=mapminmax(reshape(weather(49:4752,1),16,294),0,1); 
[humn,humps]=mapminmax(reshape(weather(49:4752,2),16,294),0,1); 
[Shrn,Shrps]=mapminmax(reshape(weather(49:4752,9),16,294),0,1); 
[Dnrn,Dnrps]=mapminmax(reshape(weather(49:4752,10),16,294),0,1); 
[Srn,Srps]=mapminmax(reshape(weather(49:4752,11),16,294),0,1); 

[outputn,outputps]=mapminmax(Ytrain,0,1);  

inputn_test1=mapminmax('apply',PVtest,inputps1);   


temn_test=mapminmax('apply',reshape(weather(4753:5424,1),16,42),temps);
humn_test=mapminmax('apply',reshape(weather(4753:5424,2),16,42),humps);
Shrn_test=mapminmax('apply',reshape(weather(4753:5424,9),16,42),Shrps);
Dnrn_test=mapminmax('apply',reshape(weather(4753:5424,10),16,42),Dnrps);
Srnn_test=mapminmax('apply',reshape(weather(4753:5424,11),16,42),Srps);

inputn_in = [temn;humn;Shrn;Dnrn;Srn;inputn1];
inputn_test_in =[temn_test;humn_test;Shrn_test;Dnrn_test;Srnn_test;inputn_test1];


% 
% XrTrain = cell(294,1);
% YrTrain = cell(294,1);
% 
% for ii=1:294
%     XrTrain{ii,1} = inputn_in(:,ii);
%     YrTrain{ii,1} = outputn(:,ii);
% end
% 
% XrTest = cell(42,1);
% for ii = 1:42
% XrTest{ii,1} = inputn_test_in(:,ii);      
% end


nn = 294;
XrTrain = cell(294,1);
YrTrain = zeros(294,64);

for ii=1:294
    XrTrain{ii,1} = inputn_in(:,ii);
    YrTrain(ii,:) = outputn(:,ii);
end

XrTest = cell(42,1);
for ii = 1:42
XrTest{ii,1} = inputn_test_in(:,ii);      
end

%% 模型构建
%% LSTM/BILSTM/GRU
% layer = [
%         sequenceInputLayer(272,Normalization="rescale-symmetric",Name="input") ];
% lgraph = layerGraph(layer);
% outputName = layer.Name;
% 
% layers = [
% 
%           lstmLayer(64,'Name','layer1')            
%           lstmLayer(64,'OutputMode',"last",'Name','layer2')
%           % bilstmLayer(64,'Name','layer1')            
%           % bilstmLayer(64,'OutputMode',"last",'Name','layer2')
%           % gruLayer(64,'Name','layer1')            
%           % gruLayer(64,'OutputMode',"last",'Name','layer2')
% 
%           fullyConnectedLayer(64,'Name','fc')
%           regressionLayer('Name','output') ];
% 
% 
% 
% lgraph = addLayers(lgraph,layers);
% lgraph = connectLayers(lgraph,outputName,'layer1');

%% MSLCnet

% num = 3;
% layer = [
%         sequenceInputLayer(272,Normalization="rescale-symmetric",Name="input") ];
% lgraph = layerGraph(layer);
% outputName = layer.Name;
% layers = [        
%         lstmLayer(64,"Name","l1")       
%         lstmLayer(64,"Name","l2")
%            ];
% layers2 = [
%             convolution1dLayer(4,num,'Padding','same','Name','conv1');
%             reluLayer
%             convolution1dLayer(3,num,'Padding','same','Name','conv2');
%             reluLayer
%             convolution1dLayer(5,num,'Padding','same','Name','conv3');
%             reluLayer
%             additionLayer(2,"Name","add1")
%             concatenationLayer(1,2,Name="concat")
%             selfAttentionLayer(1,12)
%             fullyConnectedLayer(64,'Name','fc')
%             regressionLayer('Name','output')];
% lgraph = addLayers(lgraph,layers2);
% lgraph = addLayers(lgraph,layers);
% lgraph = connectLayers(lgraph,outputName,"l1");
% lgraph = connectLayers(lgraph,outputName,'conv1');
% layer = convolution1dLayer(1,num,Name="convSkip");
% lgraph = addLayers(lgraph,layer);
% lgraph = connectLayers(lgraph,outputName,"convSkip");
% lgraph = connectLayers(lgraph,"convSkip",'add1/in2');
% lgraph = connectLayers(lgraph,"l2","concat/in2");







%% DSN
% layer = [
%         sequenceInputLayer([272 1],Normalization="rescale-symmetric",Name="input") ];
% lgraph = layerGraph(layer);
% outputName = layer.Name;
% layers = [     
%         flattenLayer("Name","f1")
%         gruLayer(64,"Name","l1")           
%         gruLayer(64,"Name","l2")
%            ];
% layers2 = [
%             convolution2dLayer(8,3,'Padding','same','Name','conv4');
%             averagePooling2dLayer([2 1])
%             convolution2dLayer(8,3,'Padding','same','Name','conv2');
%             averagePooling2dLayer([2 1])    
%             flattenLayer
%             concatenationLayer(1,2,Name="concat")
%             selfAttentionLayer(1,12)
%             fullyConnectedLayer(64,'Name','fc')
%             regressionLayer('Name','output')];
% lgraph = addLayers(lgraph,layers2);
% lgraph = addLayers(lgraph,layers);
% lgraph = connectLayers(lgraph,outputName,"f1");
% lgraph = connectLayers(lgraph,outputName,'conv4');
% lgraph = connectLayers(lgraph,"l2","concat/in2");

%% Transformer
head = 2;
layers = [ 
    sequenceInputLayer(272,Normalization="rescale-symmetric",Name="input")
    positionEmbeddingLayer(272,17,Name="pos-emb");
    additionLayer(2, Name="add")
    selfAttentionLayer(head,head*64,'AttentionMask','causal')
    selfAttentionLayer(head,head*46)
    indexing1dLayer("last")
    fullyConnectedLayer(64)
    regressionLayer];

lgraph = layerGraph(layers);
lgraph = connectLayers(lgraph,"input","add/in2");

%% CNN
% layers = [
%         sequenceInputLayer([272 1 1],Normalization="rescale-symmetric",Name="input")
%             ];
%     lgraph = layerGraph(layers);
% 
% layer =  [ 
% 
%         convolution2dLayer(6,3,'Padding','same','WeightsInitializer','he','Name','conv');
%         batchNormalizationLayer('Name','bn')
%         maxPooling2dLayer([3 1],'Stride',3,'Name','pool1')
%         convolution2dLayer(6,3,'Padding','same','WeightsInitializer','he','Name','conv2');
%         batchNormalizationLayer('Name','bn2')
%         maxPooling2dLayer([3 1],'Stride',3,'Name','pool2')
%         reluLayer('Name','elu')
%         flattenLayer('Name','flatten42')
%         fullyConnectedLayer(64,'Name','fc')
%         regressionLayer('Name','output')
%         ];
% 
% lgraph = addLayers(lgraph,layer);
% lgraph = connectLayers(lgraph,"input",'conv');

%% TCN

% layer = sequenceInputLayer(272,Normalization="rescale-symmetric",Name="input");
% lgraph = layerGraph(layer);
% dilationFactor=1;
% outputName = layer.Name;
% num = 17;
% 
% layers = [
%         convolution1dLayer(3,num,DilationFactor=1,Padding="same",Name="conv1_"+1)
%         layerNormalizationLayer
%         convolution1dLayer(3,num,DilationFactor=2,Padding="same")
%         layerNormalizationLayer 
%         reluLayer
%         additionLayer(2,Name="add_"+1)
%         % 全连接层
%         fullyConnectedLayer(64,'Name','fc')
%         regressionLayer('Name','output')];
% 
% 
% lgraph = addLayers(lgraph,layers);
% lgraph = connectLayers(lgraph,outputName,"conv1_"+1);
% layer = convolution1dLayer(1,num,Name="convSkip");
% lgraph = addLayers(lgraph,layer);
% lgraph = connectLayers(lgraph,"input","convSkip");
% lgraph = connectLayers(lgraph,"convSkip",'add_1/in2');

%% CNN-LSTM
% layers = [
%         sequenceInputLayer([272 1 1],Normalization="rescale-symmetric",Name="input")
%             ];
%     lgraph = layerGraph(layers);
% 
% layer =  [ 
% 
%         convolution2dLayer(6,3,'Padding','same','WeightsInitializer','he','Name','conv');
%         batchNormalizationLayer('Name','bn')
%         maxPooling2dLayer([3 1],'Stride',3,'Name','pool1')
%         reluLayer('Name','elu')
%         flattenLayer('Name','flatten42')
%         lstmLayer(64,'Name','l1')
%         lstmLayer(64,'OutputMode',"last",'Name','l2')
%         fullyConnectedLayer(64,'Name','fc')
%         regressionLayer('Name','output')
%         ];
% 
% lgraph = addLayers(lgraph,layer);
% lgraph = connectLayers(lgraph,"input",'conv');






%% 其他模型

% options1 = trainingOptions( 'adam', ...
%     'MaxEpochs',200, ...
%     'MiniBatchSize',nn, ...
%     'GradientThreshold',1, ...
%     'InitialLearnRate',0.001, ...
%     'LearnRateSchedule','piecewise', ...
%     'LearnRateDropPeriod',floor(nn), ...
%     'LearnRateDropFactor',0.5, ...
%     'L2Regularization',0.01,...
%     'Verbose',false, ...
%     'Plots','none' );

%% Transformer
options1 = trainingOptions( 'adam', ...
    'MaxEpochs',150, ...
    'MiniBatchSize',nn, ...
    'GradientThreshold',1, ...
    'InitialLearnRate',0.01, ...
    'LearnRateSchedule','piecewise', ...
    'LearnRateDropPeriod',floor(nn), ...
    'LearnRateDropFactor',0.5, ...
    'L2Regularization',0.01,...
    'Verbose',false, ...
    'Plots','none' );



%% 网络训练

net0 = trainNetwork(XrTrain,YrTrain,lgraph,options1);

% 预测结果

YPred = predict(net0,XrTest);

YPred = double(YPred');

% YPred = cell2mat(YPred');

% 反归一化
test_fgy0=mapminmax('reverse',YPred,outputps); 

for iii = 1:64
    if test_fgy0(iii) <0
        test_fgy0(iii) = 0;
    end
end



test_out_ = PV_testout';
test_out_ = reshape(test_out_,2688,1);
test_fgy0 = reshape(test_fgy0,2688,1);
error=abs(test_fgy0-test_out_);  
rmse = sqrt(mean((test_fgy0-(test_out_)).^2,'ALL'));
d_max = max(test_out_);
d_min = min(test_out_);
nrmse = rmse/(d_max-d_min);
r2 = 1 - norm(test_out_ -  test_fgy0)^2 / norm(test_out_ -  mean(test_out_ ))^2;
mae = mean(error);
nmae = mae/(d_max-d_min);
mape = mean(error./test_out_);
res_hou = Area_deviation_rate_calculation(test_fgy0,test_out_);
disp(['总体准确度：',num2str(mean(res_hou))])
disp(['优化前的NRMSE：',num2str(mean(nrmse))])
disp(['优化前的nmae：',num2str(mean(nmae))])
disp(['优化前的R2：',num2str(mean(r2))])
toc
% for i = 1:42
% figure
% hold on 
% plot(test_fgy0(64*i-63:64*i),"-o")
% plot(test_out_(64*i-63:64*i),"-o")
% legend('predicted value','actual value','Location','northwest')
% ylabel('predicted results')
% xlabel('time/(15min)')
% end








